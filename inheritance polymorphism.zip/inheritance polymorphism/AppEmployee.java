package com.yash.employeeextendsperson;

public class AppEmployee 
{
	public static void main(String[] args)
	{
		Employee emp = new Employee("Prakhar Gupta", 25000.10, 2021, "10236541289");
		System.out.println(emp.toString());
	}

}
