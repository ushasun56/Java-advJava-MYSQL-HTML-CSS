package com.yash.calculator;

public class CalculatorApp 
{

	public static void main(String[] args) 
	{
		Arthematic ar = new Arthematic();
		System.out.println(ar.square());

	}

}
