package com.yash.Inhr_polyQ2;

public class DogMain {

	public static void main(String[] args) 
	{
		Yorkshire y = new Yorkshire();
		y.speak();
		y.avgBreedWeight();
		Labrador l = new Labrador();
		l.speak();
		l.avgBreedWeight();
		
	}

}
