package com.yash.employeeextendsperson;

public class Person 
{
	String employeeName;
	
	Person(String employeeName)
	{
		this.employeeName=employeeName;
	}
}
