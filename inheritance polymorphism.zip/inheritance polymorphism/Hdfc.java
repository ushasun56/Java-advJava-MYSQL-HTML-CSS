package com.yash.bank;

public class Hdfc extends Bank
{
	final int depositeMoney=1500;
	int getBalance()
	{
		return depositeMoney;
		
	}
}
