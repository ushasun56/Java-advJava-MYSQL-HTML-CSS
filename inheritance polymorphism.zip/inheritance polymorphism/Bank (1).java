package com.yash.bank;

public class Bank 
{
	 int getBalance()
	 {
		 return 0;
	 }
	
}
