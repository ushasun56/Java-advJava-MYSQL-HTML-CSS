package com.yash.dogs;
/**
 * Creating a super class Dog which have abstract method
 * @author Prakhar Gupta
 *
 */
public abstract class Dog 
{
	abstract int avgBreedWeight();
}
