package com.yash.calculator;

public interface Calculator
{
	public int square(); 
}
