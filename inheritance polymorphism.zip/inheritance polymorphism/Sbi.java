package com.yash.bank;

public class Sbi extends Bank
{
	final int depositeMoney=1000;
	int getBalance()
	{
		return depositeMoney;
		
	}
}
