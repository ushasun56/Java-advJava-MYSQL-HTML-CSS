package com.yash.bank;

public class Kotak extends Bank
{
	final int depositeMoney=2000;
	int getBalance()
	{
		return depositeMoney;
		
	}
}
